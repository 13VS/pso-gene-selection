%% PSO SELECTION DEMO
%%
% 
% * Developer Er.Abbas Manthiri S
% * EMail abbasmanthiribe@gmail.com
% * Date 23-03-2017
% * <https://en.wikipedia.org/wiki/Particle_swarm_optimization Referece>
% 

%% Initialize
clc
clear all
warning off all
%% DEMO 1
row=50;
col=10;
Data=randi([1,50],[row,col]);
disp('Data---->')
disp(Data)
nOfSelection=3;
population=20;
itrationMax=inf;
fun=@meandata;
[Selection , SelectionValue]=psoSelection(Data,nOfSelection,population,itrationMax,fun);
MinimizedData=Data(:,Selection);
disp('Selection---->')
disp(Selection)
disp('SelectionValue---->')
disp(SelectionValue)
%% Demo 1 output
disp('MinimizedData---->')
disp(MinimizedData)
%% DEMO 2
nOfSelection=4;
population=10;
itrationMax=100;
fun=@stddata;
[Selection , SelectionValue]=psoSelection(Data,nOfSelection,population,itrationMax,fun);
MinimizedData=Data(:,Selection);
disp('Selection---->')
disp(Selection)
disp('SelectionValue---->')
disp(SelectionValue)
%% Demo 2 output
disp('MinimizedData---->')
disp(MinimizedData)