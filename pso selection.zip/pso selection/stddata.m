function m=stddata(data)
m=std(data);
m=mean(m(:));