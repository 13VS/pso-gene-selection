function m=meandata(data)
m=mean(data(:));